__version__ = '2.1.6'

VERSION = __version__  # synonym
