"""
Blank URLConf just to keep runtests.py happy.
"""
from django.conf.urls.defaults import *

urlpatterns = patterns('',
)
