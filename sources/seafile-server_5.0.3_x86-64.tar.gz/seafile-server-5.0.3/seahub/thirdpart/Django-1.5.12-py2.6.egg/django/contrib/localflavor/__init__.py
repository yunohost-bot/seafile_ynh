import warnings

warnings.warn("django.contrib.localflavor is deprecated. "
              "Use the separate django-localflavor package instead.",
              DeprecationWarning)
